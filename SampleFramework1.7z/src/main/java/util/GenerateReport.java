package util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class GenerateReport {
	public static final String ReportPath = System.getProperty("user.dir") + "/Reports/TestReport.html";
	public static ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(ReportPath);
	public static ExtentReports extent = new ExtentReports();

	public static String capture(WebDriver driver, String screenShotName) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String dest = System.getProperty("user.dir") + "/Reports/ErrorScreenshots/" + screenShotName + ".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);

		return dest;
	}

	@AfterSuite
	public void closeReport() {
		extent.close();
	}

}
