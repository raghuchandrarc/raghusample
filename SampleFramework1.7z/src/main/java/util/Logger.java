package util;
/**
 * The Logger class is used to log
 *
 * 
 */
public class Logger {

}
