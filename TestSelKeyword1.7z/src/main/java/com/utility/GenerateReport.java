package com.utility;

import java.io.File;

import org.testng.annotations.AfterSuite;

import com.relevantcodes.extentreports.ExtentReports;

public class GenerateReport {
	public static ExtentReports reporter;

	public static void generateReport() {
		reporter = new ExtentReports(System.getProperty("user.dir") + "/Reports/TestReport.html", true);
		reporter.addSystemInfo("Host Name", "MnT WebBanking");
		reporter.addSystemInfo("Environment", "Selenium 3.4.0");
		reporter.addSystemInfo("User Name", "TestUser");
		reporter.loadConfig(new File(System.getProperty("user.dir")+"/test-output/extent-config.xml"));
		
	}
	
	@AfterSuite
	public void closeReport(){
		reporter.close();
	}

}
