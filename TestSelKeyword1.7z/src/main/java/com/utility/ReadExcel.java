package com.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	public static XSSFRow row = null;
	public static XSSFCell cell = null;
	public static XSSFSheet sheet = null;
	public static XSSFWorkbook workbook = null;

	public static Object[][] ExcelReader(String workbookName, String SheetName) {
		File file = new File(workbookName);
		InputStream fis;
		Object object[][] = null;
		try {

			fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(SheetName);
			XSSFRow row;
			object = new Object[sheet.getLastRowNum()][5];

			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				row = sheet.getRow(i + 1);
				for (int j = 0; j < row.getLastCellNum(); j++) {
					object[i][j] = row.getCell(j, Row.CREATE_NULL_AS_BLANK).toString();

				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return object;
	}

	public static void setcelldata(String path, String sheetName, String colName, int rowNum, String data)
			throws Exception {
		// create an object of Workbook and pass the FileInputStream object into
		// it to create a pipeline between the sheet and eclipse.
		FileInputStream fis = new FileInputStream(path);
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheet(sheetName);
		int col_Num = -1;
		row = sheet.getRow(0);
		for (int i = 0; i < row.getLastCellNum(); i++) {
			if (row.getCell(i).getStringCellValue().trim().equals(colName)) {
				col_Num = i;
			}
		}

		sheet.autoSizeColumn(col_Num);
		row = sheet.getRow(rowNum - 1);
		if (row == null)
			row = sheet.createRow(rowNum - 1);

		cell = row.getCell(col_Num);
		if (cell == null)
			cell = row.createCell(col_Num);
		cell.setCellType(cell.CELL_TYPE_STRING);
		cell.setCellValue(data);
		FileOutputStream fos = new FileOutputStream(path);
		workbook.write(fos);
		fos.close();
		System.out.println("End writing " + data + " into this file path " + path);

	}

}
