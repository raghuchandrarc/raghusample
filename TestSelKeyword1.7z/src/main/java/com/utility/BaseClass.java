package com.utility;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class BaseClass {
	public static WebDriver driver;
	
	@BeforeSuite
	public void launchDriver(){
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "/BrowserDrivers/IEDriverServer.exe");
		//driver = new ChromeDriver();
		/*File file = new File(
				"C:\\Users\\Public\\Documents\\practiceWorkspace\\TestSelKeyword\\BrowserDrivers\\IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());*/
		
		
		DesiredCapabilities returnCapabilities = DesiredCapabilities.internetExplorer();
		returnCapabilities
				.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		returnCapabilities.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
	      driver=new InternetExplorerDriver(returnCapabilities);
	      driver = new EventFiringWebDriver(driver);
	      driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	@AfterSuite
	public void closeBrowser(){
		driver.quit();
	}
	

}
