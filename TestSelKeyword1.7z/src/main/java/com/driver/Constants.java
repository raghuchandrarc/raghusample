package com.driver;

public class Constants {
	public static final String Path_TestData = System.getProperty("user.dir") + "/TestSuites/FirstTestSuite.xlsx";
	public static final int Col_ID = 1;
	public static final String Col_name="TestDataIn";
	public static final String FileName="FirstTestSuite.xls";
	
	public static final int Col_DataSet = 2;
	public static final String Sheet_TestData = "Test Data";
}
