package com.operation;

import org.openqa.selenium.WebDriver;

public class KeywordExecutor {
	
	TestMethods tests = new TestMethods(); //Creating object of a TestMethod class	
	
	/**
	 * This method will execute the test methods according to the keyword provided
	 * @param keywordData
	 * @param locatorData
	 * @param inputData
	 */
	String stepExecutionResult; 
	public String execute(WebDriver driver, String keywordData,String locatorType, String object, String inputData) throws Exception{
		switch (keywordData) {
		case "OpenWebsite":
			stepExecutionResult = tests.openUrl(driver, inputData);
			break;
		case "EnterText":
			stepExecutionResult = tests.enterText(driver,locatorType,object, inputData);
			break;
		case "Click":
			stepExecutionResult = tests.click(driver,locatorType,object);
			break;
		case "getText":
			stepExecutionResult = tests.getText(driver,object,inputData);
			break;
		case "VerifyText":
			stepExecutionResult = tests.verifyText(driver,locatorType,object, inputData);
			break;
		case "waitFor":
			stepExecutionResult = tests.waitFor(driver,object, inputData);
			break;
		case "Clear":
			stepExecutionResult = tests.Clear(driver,object);
			break;
		case "Select":
			stepExecutionResult = tests.Select(driver,locatorType,object, inputData);
			break;
		default:
			System.out.println("Invalid Keyword");
			stepExecutionResult = "Invalid Keyword";
			break;
		}
		return stepExecutionResult;

	}
}
