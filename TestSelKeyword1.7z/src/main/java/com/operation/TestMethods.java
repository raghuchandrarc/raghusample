package com.operation;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.driver.Constants;
import com.utility.ReadExcel;

public class TestMethods {
	/**
	 * Method to CLICK on an Object
	 * 
	 * @param driver
	 * @param locator
	 */
	public String click(WebDriver driver, String locatorType,String object) {
		
		String result;
		try {
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			if (element != null) {
				element.sendKeys(Keys.TAB);
				element.click();
				result = "Pass :: Successfully clicked";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
		}
		System.out.println("Click Methods result is " + result);
		return result;
	}

	public String Select(WebDriver driver, String locatorType, String object, String inputData) {
		String result;
		try {
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);

			if (element != null) {
				Select oSelect = new Select(element);
				List<WebElement> elementCount = oSelect.getOptions();

				for (int i = 0; i < elementCount.size(); i++) {

					String listOfvalues = elementCount.get(i).getText().trim();

					oSelect.selectByIndex(1);
					// oSelect.selectByValue(data);
					/*
					 * if (listOfvalues.startsWith(data)) {
					 * 
					 * oSelect.selectByValue(listOfvalues);
					 * 
					 * }
					 */

				}
				result = "Pass :: Successfully Selected drop down values";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}

		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
		}
		System.out.println("Select Method result is " + result);
		return result;
	}

	/**
	 * Method to launch AUT Site
	 * 
	 * @param driver
	 * @param URL
	 */
	public String openUrl(WebDriver driver, String URL) {
		driver.get(URL);
		return "Pass :: Successfully Launched URL " + URL;
	}

	/**
	 * Method to enter some data inside textbox. text area
	 * 
	 * @param driver
	 * @param locator
	 * @param inputData
	 * @return
	 * @throws Exception 
	 */
	public String enterText(WebDriver driver, String locatorType,String object,String inputData) throws Exception {
		
		try{
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement((locator));	
		if (element != null) {
			element.sendKeys(inputData);
			
			return "Pass :: Successfullly entered " + inputData + " text";
		} else {
			System.out.println("Element not available");
			return "Failed :: Element not available";
			
			
		}
		}catch (NoSuchElementException e){
			return "Failed::"+ e;
		}
	}
	

	/**
	 * Method to Verify if text is matching with expected text message
	 * 
	 * @param driver
	 * @param locatorType
	 * @param object
	 * @param textToVerify
	 * @return
	 */
	public String verifyText(WebDriver driver,String locatorType, String object, String textToVerify) {
		
		By locator;
		locator = locatorValue(locatorType, object);
		WebElement element = driver.findElement(locator);
		if (element != null) {
			if (textToVerify.equalsIgnoreCase(element.getText())) {
				System.out.println("Text is matching");
				return "Passed :: Text is matching";
			} else {
				System.out.println("Text is not matching");
				return "Failed :: Text is not matching";

			}
		} else {
			System.out.println("Element not available");
			return "Failed :: Element not available";
		}
	}
	/**
	 * Method to GetText 
	 * 
	 * @param driver
	 * @param locator
	 * @param object
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("static-access")
	public String getText(WebDriver driver,String locatorType, String object) throws Exception {
		String result;
		try {
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			if (element != null) {
				String capaturedData=element.getText();
				System.out.println("Capturing Data is "+capaturedData);
			    int iRownum= 2;
			    ReadExcel.setcelldata(Constants.Path_TestData, Constants.Sheet_TestData,Constants.Col_name,iRownum, capaturedData);
				result = "Pass :: Successfully Capturing Data";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
		}
		System.out.println("getText Methods result is " + result);
		return result;
	}
	
	public String waitFor(WebDriver driver, String locator, String Inputwait) throws InterruptedException{
		//driver.get(Inputwait);
		Thread.sleep(5000);
		return "Pass :: Wait For 5 seconds " + Inputwait;
		
	}
	/**
	 * Method to clear on an Object
	 * 
	 * @param driver
	 * @param locator
	 */
	public String Clear(WebDriver driver, String locator) {
		
		String result;
		try {
			WebElement element = driver.findElement(By.xpath(locator));
			if (element != null) {
				element.sendKeys(Keys.TAB);
				element.clear();
				result = "Pass :: Successfully Cleared Field";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
		}
		System.out.println("Clear Methods result is " + result);
		return result;
	}
	 public static By locatorValue(String locatorType,String object) {
			By by;
			switch (locatorType) {
			case "id":
				by = By.id(object);
				break;
			case "name":
				by = By.name(object);
				break;
			case "xpath":
				by = By.xpath(object);
				break;
			case "css":
				by = By.cssSelector(object);
				break;
			case "linkText":
				by = By.linkText(object);
				break;
			case "partialLinkText":
				by = By.partialLinkText(object);
				break;
			case "className":
				by = By.className(object);
				break;
			case "tagName":
				by = By.tagName(object);
				break;
			default:
				by = null;
				break;
			}
			return by;
		}

}
