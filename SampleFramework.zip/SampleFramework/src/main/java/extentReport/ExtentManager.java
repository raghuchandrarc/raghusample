package extentReport;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.relevantcodes.extentreports.ExtentReports;


//OB: ExtentReports extent instance created here. That instance can be reachable by getReporter() method.

public class ExtentManager {

    private static ExtentReports extent;

    public synchronized static ExtentReports getReporter(){
        if(extent == null){
            //Set HTML reporting file location
            String workingDir = System.getProperty("user.dir");
            extent = new ExtentReports(workingDir+"\\SCREENSHOT\\ExtentReportResults.html", true);
            extent.addSystemInfo("Test Tool", "Selenium 3.5.0");
        }
        return extent;
    }

	
}
