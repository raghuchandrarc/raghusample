package model;

public class Constants {
	public static final String Path_TestData = System.getProperty("user.dir") + "/TestSuites&TestCases/TestCases2.xlsx";
	//public static final String Path_TestData = System.getProperty("user.dir") + "/TestSuites/TestDataSuite.xlsx";
	public static final String TestSuitePath = System.getProperty("user.dir") + "/TestSuites&TestCases/TestCases2.xlsx";
	public static final String FileName = "CITestSuite.xlsx";
	public static final String Controller = System.getProperty("user.dir") + "/Controller.xlsx";
	
	public static final int Col_DataSet = 1;
	public static final String Sheet_TestData = "Test Data";
}
