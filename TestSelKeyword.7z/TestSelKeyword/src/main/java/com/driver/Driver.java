package com.driver;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.utility.ReadExcel;

public class Driver {

	public static void main(String[] args) throws Exception {

		String moduleName, runData;

		XmlSuite myXmlSuite = new XmlSuite();
		myXmlSuite.setName("CCTS Test Suite");

		XmlTest myTest = new XmlTest(myXmlSuite);
		myTest.setName("CCTS Test");
		List<XmlClass> myClasses = new ArrayList<XmlClass>();
		String testSuiteName = Constants.Controller;

		Object[][] testData = ReadExcel.ExcelReader(testSuiteName, "Module");
		
		for (Object[] objects : testData) {
			moduleName = (String) objects[0];
			runData = (String) objects[1];
			if (runData.equals("Y")) {
				myClasses.add(new XmlClass("com.tests." + moduleName));
			}
		}

		myTest.setXmlClasses(myClasses);
		List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
		mySuites.add(myXmlSuite);

		System.out.println(myXmlSuite.toXml());

		TestNG testNg = new TestNG();
		testNg.setXmlSuites(mySuites);
		testNg.run();

	}

}
