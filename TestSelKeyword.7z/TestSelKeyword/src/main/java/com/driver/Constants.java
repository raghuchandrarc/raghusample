package com.driver;

public class Constants {
	public static final String Path_TestData = System.getProperty("user.dir") + "/TestSuites/FirstTestSuite.xlsx";
	//public static final String Path_TestData = System.getProperty("user.dir") + "/TestSuites/TestDataSuite.xlsx";
	public static final String TestSuitePath = System.getProperty("user.dir") + "/TestSuites/FirstTestSuite.xlsx";
	public static final String FileName = "FirstTestSuite.xlsx";
	public static final String Controller = System.getProperty("user.dir") + "/Controller.xlsx";
	
	public static final int Col_DataSet = 0;
	public static final String Sheet_TestData = "Test Data";
}
