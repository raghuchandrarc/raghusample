package com.utility;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class GenerateReport {
	public static final String ReportPath = System.getProperty("user.dir") + "/Reports/TestReport.html";
	public static ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(ReportPath);
	public static ExtentReports extent = new ExtentReports();
	public static ExtentTest test;

	public static String capture(WebDriver driver, String screenShotName) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String dest = System.getProperty("user.dir") + "/Reports/ErrorScreenshots/" + screenShotName + ".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);

		return dest;
	}

	public static void generateReport(String testSheetName) {
		extent.setSystemInfo("Environment", "Selenium 3.4.0");
		extent.setSystemInfo("User Name", "TestUser");
		test = GenerateReport.extent.createTest(testSheetName + "_TestCase");
		test.assignCategory(testSheetName);
		test.info(testSheetName + "_TestCase Details");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setTheme(Theme.STANDARD);
		htmlReporter.config().setReportName("CCTS Test Results");
		htmlReporter.config().setEncoding("utf-8");
		htmlReporter.config().setDocumentTitle("Automation Test Results");
	}

	@AfterSuite
	public void closeReport() {
		extent.close();
	}

}
