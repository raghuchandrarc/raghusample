package com.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static XSSFRow row = null;
	public static XSSFCell cell = null;
	public static XSSFSheet sheet = null;
	public static XSSFWorkbook workbook = null;

	@SuppressWarnings("deprecation")
	public static Object[][] ExcelReader(String workbookName, String SheetName) throws Exception {

		File file = new File(workbookName);
		InputStream fis;
		Object object[][] = null;
		String cellval = null;

		try {

			fis = new FileInputStream(file);

			workbook = new XSSFWorkbook(fis);
			XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

			sheet = workbook.getSheet(SheetName);
			object = new Object[sheet.getLastRowNum()][7];
			DataFormatter dataFormatter = new DataFormatter();
			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				row = sheet.getRow(i + 1);
				for (int j = 0; j < row.getLastCellNum(); j++) {
					cell = sheet.getRow(i).getCell(j);

					cell = row.getCell(j, Row.CREATE_NULL_AS_BLANK);
					if (cell != null) {

						switch (cell.getCellType()) {
						case XSSFCell.CELL_TYPE_BOOLEAN:
							cellval = cell.getBooleanCellValue() + "";
							break;
						case XSSFCell.CELL_TYPE_NUMERIC:
							cellval = String.valueOf(cell.getNumericCellValue()) + "";
							String data = dataFormatter.formatCellValue(cell);
							cellval = data;

							break;
						case XSSFCell.CELL_TYPE_STRING:
							cellval = cell.getStringCellValue();

							break;
						case XSSFCell.CELL_TYPE_FORMULA:
							cell.getCachedFormulaResultType();
							evaluator.evaluateAll();
							String formulaCell = evaluator.evaluateInCell(cell).toString();
							cellval = formulaCell.toString();
							// Hyperlink h = cell.getHyperlink();
							// cellval=h.getAddress();
							// cellval.toString();
							// System.out.println("HyperLink "+cellval);

							break;

						default:
							break;

						}

					}
					object[i][j] = cellval.toString();

				}

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return object;
	}

	
	public static void writeData(String Path, String sheet, String Testdata, int colNum) throws Exception {
		FileInputStream fis = new FileInputStream(Path);

		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheetName = workbook.getSheet(sheet);

		Object[][] datatypes = { { Testdata } };
		int rowNum = sheetName.getLastRowNum();
		// int rowNum = 0;
		for (Object[] datatype : datatypes) {

			Row row = sheetName.getRow(rowNum++);
			// Row row = sheetName.getRow(rowNum);
			for (Object field : datatype) {
				Cell cell = row.createCell(colNum++);
				if (field instanceof String) {
					cell.setCellValue((String) field);
				} else if (field instanceof Integer) {
					cell.setCellValue((Integer) field);
				} else if (field instanceof Double) {
					cell.setCellValue((Double) field);
				}
			}
		}

		try {
			FileOutputStream outputStream = new FileOutputStream(Path);
			XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
			workbook.write(outputStream);
			workbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("End writing Data " + Testdata + " into this file path: " + Path + " into this Sheet name: "
				+ sheetName + "");

	}

	public static int getRowCount(String SheetName) {
		int iNumber = 0;
		try {
			sheet = workbook.getSheet(SheetName);
			iNumber = sheet.getLastRowNum() + 1;
			// iNumber = sheet.getRow(0).getLastCellNum();
		} catch (Exception e) {
			Log.error("Not able to count row used --- " + e.getMessage());
		}
		return iNumber;
	}
	/*
	 * public static void writeData(String Path, String sheet, String data, int
	 * colNum) throws Exception { FileInputStream fis = new
	 * FileInputStream(Path);
	 * 
	 * XSSFWorkbook workbook = new XSSFWorkbook(fis); XSSFSheet sheetName =
	 * workbook.getSheet(sheet);
	 * 
	 * Object[][] datatypes = { { data } }; //int rowNum =
	 * sheetName.getLastRowNum(); int rowNum = 0; for (Object[] datatype :
	 * datatypes) {
	 * 
	 * Row row = sheetName.getRow(rowNum++); //Row row =
	 * sheetName.getRow(rowNum); for (Object field : datatype) { Cell cell =
	 * row.createCell(colNum++); if (field instanceof String) {
	 * cell.setCellValue((String) field); } else if (field instanceof Integer) {
	 * cell.setCellValue((Integer) field); } else if (field instanceof Double) {
	 * cell.setCellValue((Double) field); } } }
	 * 
	 * try { FileOutputStream outputStream = new FileOutputStream(Path);
	 * XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
	 * workbook.write(outputStream); workbook.close(); } catch
	 * (FileNotFoundException e) { e.printStackTrace(); } catch (IOException e)
	 * { e.printStackTrace(); } System.out.println("End writing Data " + data +
	 * " into this file path: " + Path + " into this Sheet name: " + sheetName +
	 * "");
	 * 
	 * }
	 */

	

}
