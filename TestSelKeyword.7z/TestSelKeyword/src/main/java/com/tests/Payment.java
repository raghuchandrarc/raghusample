package com.tests;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.actions.KeywordExecutor;
import com.aventstack.extentreports.Status;
import com.driver.BaseClass;
import com.driver.Constants;
import com.utility.GenerateReport;
import com.utility.Log;
import com.utility.ReadExcel;

public class Payment extends BaseClass {

	/**
	 * Main Driver method that will drive the execution
	 * 
	 * @param args
	 */
	String testSuiteFile = Constants.TestSuitePath;
	KeywordExecutor executor = new KeywordExecutor();
	String testSheetName = this.getClass().getSimpleName();
	String stepExecutionResult[];

	@BeforeClass()
	public void beforeTestMethod() {
		GenerateReport.extent.attachReporter(GenerateReport.htmlReporter);
		GenerateReport.generateReport(testSheetName);
		
	}

	@Test(dataProvider = "PaymentData")
	public void payment(String TestCaseId,String TestCaseName, String keyword, String locatorType, String locator, String inputData,
			String purpose) throws Exception {
		DOMConfigurator.configure("log4j.xml");
		Log.startTestCase(TestCaseId,TestCaseName, inputData,keyword);
		stepExecutionResult = executor.execute(driver, TestCaseId, TestCaseName,keyword, locatorType, locator, inputData)
				.split("::");
		System.out.println(stepExecutionResult[0] + "---" + stepExecutionResult[1]);
		if (stepExecutionResult[0].toUpperCase().contains("PASS")) {
			GenerateReport.test.log(Status.PASS, TestCaseId + "---" + TestCaseName + "---" + stepExecutionResult[1]);
		} else if (stepExecutionResult[0].toUpperCase().contains("FAIL")) {
			GenerateReport.test.log(Status.FAIL, TestCaseId + "---" + TestCaseName + "---" + stepExecutionResult[1]);
			String ErrorscreenShotPath = GenerateReport.capture(driver, TestCaseId);
			GenerateReport.test.addScreenCaptureFromPath(ErrorscreenShotPath);
			GenerateReport.test.fail("Test Case Failed ID " + TestCaseId);
			GenerateReport.test.log(Status.INFO, "Testcase ID  " + TestCaseId+ " has been failed refer below Screen shot" );
		}
		Log.endTestCase(TestCaseId,TestCaseName);

	}

	@DataProvider
	public Object[][] PaymentData() throws Exception {
		Object testData[][] = ReadExcel.ExcelReader(testSuiteFile, testSheetName);
		for (Object[] objects : testData) {
			for (Object object : objects) {
				System.out.println(object);
			}
		}
		return testData;
	}

	@AfterClass
	public void closeTest() {
		GenerateReport.extent.flush();

	}

}
