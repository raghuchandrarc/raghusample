package com.actions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.driver.Constants;
import com.utility.Log;
import com.utility.ReadExcel;




public class TestMethods {
	String alertText = null;

	/**
	 * Method to CLICK on an Object
	 * 
	 * @param driver
	 * @param locator
	 * @throws InterruptedException
	 */
	public String click(WebDriver driver, String locatorType, String object) throws InterruptedException {
		
		String result;
		
		try {
			
			Log.info("Clicking on Webelement... " + object);
			By locator;
			locator = locatorValue(locatorType, object);

			WebElement element = driver.findElement(locator);
			

			if (element != null) {

				element.sendKeys(Keys.TAB);
				element.click();
				
				result = "Pass :: Successfully clicked";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
			Log.error("Not able to Click on Element--- " + e.getMessage());
		}
		System.out.println("Click Methods result is " + result);
		return result;
	}
	
	public String clickNSelect(WebDriver driver, String locatorType, String object) throws InterruptedException {
		Log.info("Clicking on Webelement... " + object);
		String result;

		try {
			By locator;
			locator = locatorValue(locatorType, object);

			WebElement element = driver.findElement(locator);

			if (element != null) {

				element.click();
				wait1(2000);
				element.sendKeys(Keys.DOWN);

				result = "Pass :: Successfully clicked";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
			Log.error("Not able to Click on Element--- " + e.getMessage());
		}
		System.out.println("Click Methods result is " + result);
		return result;
	}
	public String enterTextSelect(WebDriver driver, String locatorType, String object, String inputData) throws Exception {

		try {
			Log.info("Entering the text into... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement((locator));
			if (element != null) {
				element.sendKeys(inputData);
				element.sendKeys(Keys.ENTER);

				return "Pass :: Successfully entered data   " + inputData + "   ";
			} else {
				System.out.println("Element not available");
				return "Failed :: Element not available";

			}
		} catch (NoSuchElementException e) {
			Log.error("Not able to Enter Input Data --- " + e.getMessage());
			return "Failed::" + e.getMessage();
		}
	}


	/**
	 * Method to launch AUT Site
	 * 
	 * @param driver
	 * @param URL
	 */
	public  String openUrl(WebDriver driver, String URL) {
		try {
			Log.info("Navigating to URL... " + URL);
			driver.get(URL);
		} catch (Exception e) {
			Log.error("Not able to Navigate --- " + e.getMessage());

		}
		return "Pass :: Successfully Launched URL   " + URL;

	}

	/**
	 * Method to enter some data inside textbox. text area
	 * 
	 * @param driver
	 * @param locator
	 * @param inputData
	 * @return
	 * @throws Exception
	 */
	public String enterText(WebDriver driver, String locatorType, String object, String inputData) throws Exception {

		try {
			Log.info("Entering the text into... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement((locator));
			if (element != null) {
				element.sendKeys(inputData);

				return "Pass :: Successfully entered data   " + inputData + "   ";
			} else {
				System.out.println("Element not available");
				return "Failed :: Element not available";

			}
		} catch (NoSuchElementException e) {
			Log.error("Not able to Enter Input Data --- " + e.getMessage());
			return "Failed::" + e.getMessage();
		}
	}

	/**
	 * Method to Verify if text is matching with expected text message
	 * 
	 * @param driver
	 * @param locatorType
	 * @param object
	 * @param textToVerify
	 * @return
	 */
	public String verifyText(WebDriver driver, String locatorType, String object, String textToVerify) {
		try {
			Log.info("verifyText in..." + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			if (element != null) {
				if (textToVerify.equalsIgnoreCase(element.getText())) {
					System.out.println("Text is matching");
					return "Passed :: Text " + textToVerify + " is matching";
				} else {
					System.out.println("Text is not matching");
					return "Failed :: Text " + textToVerify + "  is not matching";

				}
			} else {
				System.out.println("Element not available");
				return "Failed :: Element not available";
			}
		} catch (NoSuchElementException e) {
			Log.error("Not able to verifyText --- " + e.getMessage());
			return "Failed::" + e;
		}
	}
	

	/**
	 * Method to GetText
	 * 
	 * @param driver
	 * @param locator
	 * @param object
	 * @return
	 * @throws Exception
	 */
	public String getText(WebDriver driver, String locatorType, String object) throws Exception {
		String result;
		try {
			Log.info("Getting the InnerText...  " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			if (element != null) {
				String capaturedData = element.getText();
				//String GetpaymentID = capaturedData.replaceAll("\\D+", "");
				highLightElement(driver, element);
				System.out.println("Capturing Data is " + capaturedData);
				//ReadExcel.writeExcel(Constants.Path_TestData,Constants.FileName, Constants.Sheet_TestData, capaturedData);
				ReadExcel.writeData(Constants.Path_TestData, Constants.Sheet_TestData, capaturedData, 2);
				result = "Pass :: Successfully Capturing Data";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
			Log.error("Not able to InnerText --- " + e.getMessage());
		}
		System.out.println("getText Methods result is " + result);
		return result;
	}

	public String waitFor(WebDriver driver, String locator, String Inputwait) throws InterruptedException {
		Thread.sleep(5000);
		return "Pass :: Waiting For 5 seconds ";

	}

	/**
	 * Method to clear data on an TextField * 
	 * @param driver
	 * @param locator
	 * @param object
	 */
	public String Clear(WebDriver driver, String locatorType, String object) {

		String result;
		try {
			Log.info("Clearing the Text In...  " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			if (element != null) {
				element.sendKeys(Keys.TAB);
				element.clear();
				result = "Pass :: Successfully Cleared Field";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
			Log.error("Not able to Clear Text --- " + e.getMessage());
		}
		System.out.println("Clear Methods result is " + result);
		return result;
	}

	/**
	 * Method to Select on an Data in dropDown
	 * 
	 * @param driver
	 * @param locator
	 * @param object
	 * @param inputData
	 */

	public String Select(WebDriver driver, String locatorType, String object, String inputData) {
		String result;
		
		try {
			Log.info("Selecting Values from Dropdown... " + inputData);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);

			if (element != null) {
				Select oSelect = new Select(element);
				List<WebElement> elementCount = oSelect.getOptions();

				for (int i = 0; i < elementCount.size(); i++) {

					oSelect.selectByIndex(1);

				}
				result = "Pass :: Successfully Selected  drop down values";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}

		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
			Log.error("Not able to Select values from Dropdown --- " + e.getMessage());
		}
		System.out.println("Select Method result is Pass" + result);
		return result;
	}
	/**
	 *Select the multiple value from a dropdown list
	 */
	public String selectFromListDropDown(WebDriver driver, String locatorType, String object, String inputData) {
		String result;
		try {
			Log.info("Selecting Values from Dropdown... " + inputData);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			if (element != null) {
				wait1(2000);
				Select oSelect = new Select(element);
				List<WebElement> elementCount = oSelect.getOptions();
				for (WebElement element1 : elementCount) {

					if (element1.getText().equals(inputData)) {
						element1.click();
						break;
					}
				}
				result = "Pass :: Successfully Selected " + inputData + " drop down values";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
			Log.error("Not able to Select values from Dropdown --- " + e.getMessage());
		}
		System.out.println("Select Method result is " + result);
		return result;

	}
	/**
	 *Select from the drop down list,if the drop down element tag is "SELECT" then use this method
	 */
	public String selectDropDownByVisibleText(WebDriver driver, String locatorType, String object, String inputData) {
		String result;
		try {
			Log.info("Inside selectDropDownByVisibleText... " + inputData);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			if (element != null) {
				wait1(2000);
				WebDriverWait wait = new WebDriverWait(driver, 30);
				wait.pollingEvery(2, TimeUnit.SECONDS).until(ExpectedConditions.elementToBeClickable(element));
				Select sel = new Select(element);
				sel.selectByVisibleText(inputData);
				wait1(2000);
				result = "Pass :: Successfully Selected " + inputData + " drop down values";
			} else {
				System.out.println("Element not available");
				result = "Fail :: Element not available";
			}
		} catch (NoSuchElementException e) {
			result = "Failed :: Element not available - " + e;
			Log.error("Not able to Select values from DropDownByVisibleText --- " + e.getMessage());
		}
		System.out.println("Select DropDownByVisibleText result is " + result);
		return result;

	}


	
	/**
	 * Method to waitNclick
	 * 
	 * @param driver
	 * @param locatorType
	 * @param object
	 */
	
	public String waitNclick(WebDriver driver, String locatorType, String object) {

		try {
			Log.info("waitNclick... " + object);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			wait.until(ExpectedConditions.elementToBeClickable(element)).click();
		} catch (Exception e) {
			Log.error(" Not able to perform waitNclick--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully waitNclick";

	}

	public String waitForElement( WebDriver driver,String locatorType,String object) {
		waitForElementPoll(driver,locatorType,  object);

		return "Pass :: Fluent Wait ";
	}
	/**
	 * Method to waitForElementPoll
	 * 
	 * @param driver
	 * @param locatorType
	 * @param object
	 */

	public WebElement waitForElementPoll(WebDriver driver,String locatorType,  String object) {
		int count = 0;
		WebDriverWait wait = null;
		By locator;
		locator = locatorValue(locatorType, object);

		while (!(wait.until(ExpectedConditions.presenceOfElementLocated(locator)).isDisplayed())) {
			wait = new WebDriverWait(driver, 60);
			wait.pollingEvery(5, TimeUnit.MILLISECONDS);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed();
			wait.until(ExpectedConditions.presenceOfElementLocated(locator)).isDisplayed();
			wait.until(ExpectedConditions.presenceOfElementLocated(locator)).click();
			count++;
			if (count == 100) {
				break;
			}
			return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		}
		return wait.until(ExpectedConditions.presenceOfElementLocated(locator));

	}
	/**
	 *Makes the driver to sleep for specified time
	 */
	public String sleepDriver(WebDriver driver, String locatorType, String object,String sleeptime) {
		try {
			Integer i = Integer.parseInt(sleeptime);
			System.out.println(i);
			Thread.sleep(i);
			
		} catch (InterruptedException e) {
			Log.error(" Not able to perform waitNclick--- " + e.getMessage());
			return "Failed::" + e;

		}
		return "Pass :: Successfully sleepDriver";
	}

	/**
	 * Method to VerifyNotEqual
	 * 
	 * @param driver
	 * @param locatorType
	 * 
	 */

	public String VerifyNotEqual(WebDriver driver, String locatorType, String object, String expected) {
		try {
			Log.info("Verifying Values... " + expected);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);

			String actual = element.getText();
			if (expected.equals(actual)) {
				System.out.println("Text is matching");
				return "Failed :: Text " + expected + " is Equal";
			} else {
				System.out.println("Text is not matching");
				return "Passed :: Text " + expected + "  is not Equal";
			}
		} catch (Exception e) {
			Log.error("Verification failed --- " + e.getMessage());
			return "Failed::" + e;
		}

	}

	/**
	 * Method to closeBrowser
	 * 
	 * @param driver
	 * @param locatorType
	 */
	public String closeBrowser(WebDriver driver, String locatorType) {
		try {
			Log.info("Closing the browser");
			driver.close();
		} catch (Exception e) {
			Log.error("Not able to Close the Browser --- " + e.getMessage());
		}
		return "Pass :: Successfully Closed Browser ";
	}
	
	/**
	 * Method to searchNverifyInlist
	 * 
	 * @param driver
	 * @param locatorType
	 * @param object
	 * @param data
	 */

	public static void searchNverifyInlist(WebDriver driver, String locatorType, String object, String data) {
		try {

			Log.info("Searching Value In  ... " + object);
			By locator;
			locator = locatorValue(locatorType, object);

			List<WebElement> tabElements = driver.findElements(locator);

			for (int i = 0; i < tabElements.size(); i++) {
				String getData = tabElements.get(i).getText().trim();

				if (getData.equals(data)) {
					System.out.println("Name Found  " + getData);
					break;

					// tabElements.get(i).click();
				}
			}
		} catch (Exception e) {
			Log.error("Value Not Found--- " + e.getMessage());
		}
	}
	/**
	 * Method to tableValueVerify Tested
	 * 
	 * @param driver
	 * @param locatorType
	 * @param object
	 * @param expected
	 */

	@SuppressWarnings("unused")
	public String tableValueVerify(WebDriver driver, String locatorType, String object, String InputData) {
		System.out.println("testdata "+ InputData);
		//String InputData = expected.replaceAll("\\D+", "");

		try {

			Log.info("Searching Value in Table  ... " + object);
			System.out.println("testdata " + InputData);

			By locator;
			locator = locatorValue(locatorType, object);

			// To locate table.
			WebElement mytable = driver.findElement(locator);

			if (mytable != null) {
				// To locate rows of table.
				List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));

				// To calculate no of rows In table.
				int rows_count = rows_table.size();

				// Loop will execute till the last row of table.
				for (int row = 0; row < rows_count; row++) {

					// To locate columns(cells) of that specific row.
					List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));

					// To calculate no of columns (cells). In that specific row.
					int columns_count = Columns_row.size();
					System.out.println("Number of cells In Row " + row + " are " + columns_count);

					// Loop will execute till the last cell of that specific
					// row.
					for (int column = 0; column < columns_count; column++) {

						// To retrieve text from that specific cell.
						String celtext = Columns_row.get(column).getText().trim();
						System.out.println(
								"Cell Value of row number " + row + " and column number " + column + " Is " + celtext);
						if (celtext.equals(InputData)) {
							System.out.println("Input TestData " + InputData + " is Found");
							return "Passed :: Data Found : Successfully Verified data " + InputData + " ";
						}

					}
					{
						System.out.println("Input TestData  " + InputData + " is NotFound");

					}

				}

			} else {
				System.out.println("Element not available");
				return "Failed :: Element not available";
			}
		} catch (Exception e) {
			Log.error("Value Not Found--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Failed :: Failed  Verified Data " + InputData + "  in table";
	}
	
	
	/**
	 * Method to tableValueVerify
	 * 
	 * @param driver
	 * @param locatorType
	 * @param object
	 * @param expected
	 */

	public String tableValueClick(WebDriver driver, String locatorType, String object, String expected) {
		String InputData = expected.replaceAll("\\D+", "");
		try {
			

			Log.info("Searching Value in Table  ... " + object);
			System.out.println("testdata "+expected);
			By locator;
			locator = locatorValue(locatorType, object);
			
			// To locate table.
			WebElement mytable = driver.findElement(locator);
			
			// To locate rows of table.
			List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
			
			// To calculate no of rows In table.
			int rows_count = rows_table.size();
			
			// Loop will execute till the last row of table.
			for (int row = 0; row < rows_count; row++) {
				
				// To locate columns(cells) of that specific row.
				List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
				
				// To calculate no of columns (cells). In that specific row.
				int columns_count = Columns_row.size();
				System.out.println("Number of cells In Row " + row + " are " + columns_count);
				
				// Loop will execute till the last cell of that specific row.
				for (int column = 0; column < columns_count; column++) {

					// To retrieve text from that specific cell.
					String celtext = Columns_row.get(column).getText().trim();
					System.out.println(
							"Cell Value of row number " + row + " and column number " + column + " Is " + celtext);
					if (Columns_row.get(column).getText().trim().equals(InputData)) {
						//highLightElementsinTable(driver, Columns_row);
						System.out.println("Input TestData " + InputData + " is Found");
						return "Passed :: Data Found : Successfully Verified Data " + InputData + " ";
					}

				}
				{
					System.out.println("Input TestData  " + InputData + " is NotFound");

				}

			}
		} catch (Exception e) {
			Log.error("Value Not Found--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Failed :: Failed  Verified Data " + InputData + "  in table";
	}
	
	/**
	 * Method to VerifyLinks
	 * 
	 * @param driver
	 * @param locatorType
	 * @param object
	 * @param expected
	 */

	public String VerifyLinks(WebDriver driver, String locatorType, String object, String expected) {
		try {
			Log.info("Searching Links in   ... " + object);
			/*
			 * By locator; locator = locatorValue(locatorType, object);
			 */
			List<WebElement> linkElements = driver.findElements(By.tagName("a"));
			String[] linkTexts = new String[linkElements.size()];
			int i = 0;

			// extract the link texts of each link element
			for (WebElement e : linkElements) {
				linkTexts[i] = e.getText();
				i++;
			}

			// test each link
			for (String t : linkTexts) {
				driver.findElement(By.linkText(t)).click();
				if (driver.getTitle().equals(expected)) {
					System.out.println("\"" + t + "\"" + " is under construction.");
				} else {
					System.out.println("\"" + t + "\"" + " is working.");
				}
			}
		} catch (Exception e) {
			Log.error("Value Not Found--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully " + expected + " Verified link in table";
	}
	
	

	public static String highLightElement(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {

			System.out.println(e.getMessage());
		}

		js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", element);
		return "Pass";

	}
	

	/**
	 *Make the driver to wait for specified amount of time
	 */
	public static String wait1(long i) {
		try {
			Thread.sleep(i);
		} catch (InterruptedException e) {
		}
		return "Pass";
	}
	/**
	 *Mouse hovering on the element is performed
	 */
	public String singleMouseHover(WebDriver driver, String locatorType, String object) {
		try {
			Actions action = new Actions(driver);
			Log.info("Mouse hovering..." + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement element = driver.findElement(locator);
			action.moveToElement(element).perform();
		} catch (NoSuchElementException e) {
			Log.error("Not able to perform Mouse hovering --- " + e.getMessage());
			return "Failed::" + e.getMessage();

		}

		return "Pass ::  Successfully singleMouseHovered";

	}

	
	/**
	 *Right clicks on the element
	 */
	public String rightClick(WebDriver driver, String locatorType, String object, String expected) {
		try {
			Log.info("right click on  ... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			Actions action = new Actions(driver);
			WebElement rightClick = driver.findElement(locator);
			action.contextClick(rightClick).perform();
		} catch (Exception e) {
			Log.error(" Not able to perform rightClick--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully rightClicked";

	}
	/**
	 *Switch To frame( html inside another html)
	 * Not tested
	 */
	public String switchToFrame(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("switchToFrame on  ... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement switchToFrame = driver.findElement(locator);
			driver.switchTo().frame(switchToFrame);
		} catch (Exception e) {
			Log.error(" Not able to perform switchToFrame--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully Switch To frame( html inside another html)";

	}

	/**
	 *Switch back to previous frame or html
	 * Not tested
	 */
	public String switchOutOfFrame(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("switchOutOfFrame   ... " + object);
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			Log.error(" Not able to perform  previous frame or html--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  previous frame or html";
	}
	

	/**
	 *Alert accept meaning click on OK button
	 */
	public String alertAccept(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("inside alertAccept()  ... ");
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.alertIsPresent());
			wait1(2000);
			Alert alert = driver.switchTo().alert();
			wait1(2000);
			alert.accept();
		} catch (Exception e) {
			Log.error(" Not able to alertAccept--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  alertAccept()";
	}
	/**
	 * @param model
	 * Verify the alert text
	 */
	public String verifyalertText(WebDriver driver, String locatorType, String object, String data) {
		// model.getElement().get(0).click();
		try {
			Log.info("inside alertAccept()  ... ");
			/*
			 * By locator; locator = locatorValue(locatorType, object);
			 * WebElement verifyalertText = driver.findElement(locator);
			 * verifyalertText.click();
			 */
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.alertIsPresent());
			wait1(1000);
			Alert alert = driver.switchTo().alert();
			wait1(1000);
			if (!(alertText == null)) {
				alertText = null;
			}
			alertText = alert.getText();
			Assert.assertEquals(alertText.toString(), data);
		} catch (Exception e) {
			Log.error(" Not able to verifyalertText--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  verifyalertText";
	}
	
	
	/**
	 *Switch back to the parent window
	 */
	public String switchToParentWindow(WebDriver driver) {
		try {
			Log.info("switchToParentWindow  ... ");
			String parentWindow = driver.getWindowHandle();
			driver.switchTo().window(parentWindow);
		} catch (Exception e) {
			Log.error(" Not able to switchToParentWindow--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  switchToParentWindow";
	}
	/**
	 *Switch to the child window
	 */
	public String switchToChildWindow(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("switchToChildWindow  ... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement switchToChildWindow = driver.findElement(locator);
			switchToChildWindow.click();

			String parent = driver.getWindowHandle();
			Set<String> windows = driver.getWindowHandles();

			try {
				if (windows.size() > 1) {
					for (String child : windows) {
						if (!child.equals(parent)) {

							if (driver.switchTo().window(child).getTitle().equals(switchToChildWindow)) {

								driver.switchTo().window(child);
							}

						}
					}
				}
			} catch (Exception e) {

				throw new RuntimeException("Exception", e);
			}
		} catch (Exception e) {
			Log.error(" Not able to switchToChildWindow--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  switchToChildWindow";

	}
	/**
	 *Scrolls down the page till the element is visible
	 */
	public String scrollElementIntoView(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("scrollElementIntoView started  ... " + object);
			{
				wait1(1000);

				By locator;
				locator = locatorValue(locatorType, object);
				WebElement scrollElementIntoView = driver.findElement(locator);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
						scrollElementIntoView);
				wait1(1000);
			}
		} catch (Exception e) {
			Log.error(" Not able to scrollElementIntoView --- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  scrollElementIntoView";

	}

	/**
	 *Scrolls down the page till the element is visible and clicks on the 
	 *element
	 */
	public String scrollElementIntoViewClick(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("scrollElementIntoViewClick ... " + object);
			Actions action = new Actions(driver);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement scrollElementIntoViewClick = driver.findElement(locator);
			action.moveToElement(scrollElementIntoViewClick).click().perform();
		} catch (Exception e) {
			Log.error(" Not able to scrollElementIntoViewClick --- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  scrollElementIntoViewClick";
	}
	/**
	 * @param driver
	 * Lets say there is header menu bar, on hovering the mouse, drop down should be displayed
	 */
	public String dropDownByMouseHover(WebDriver driver, String locatorType, String object, String hoverDataobject) {
		try {
			Log.info("dropDownByMouseHover ... " + object);
			
			Actions action = new Actions(driver);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement dropDownByMouseHover = driver.findElement(locator);

			action.moveToElement(dropDownByMouseHover).perform();
			WebElement subElement = driver.findElement(By.xpath(hoverDataobject));
			action.moveToElement(subElement);
			wait1(5000);
			action.click().build().perform();
		} catch (Exception e) {
			Log.error(" Not able to dropDownByMouseHover --- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  dropDownByMouseHover";

	}
	/**
	 *Double clicks on the particular element
	 */
	public String doubleClick(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("doubleClick ... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement doubleClick = driver.findElement(locator);
			Actions action = new Actions(driver);
			action.doubleClick((WebElement) doubleClick).perform();
		} catch (Exception e) {
			Log.error(" Not able to doubleClick --- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  doubleClick";

	}
	/**
	 * @param driver
	 * File upload in IE browser.
	 */
	public String fileUploadinIE(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("fileUploadinIE ... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement fileUploadinIE = driver.findElement(locator);
			fileUploadinIE.click();
			StringSelection ss = new StringSelection("");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
			Robot r;
			try {
				r = new Robot();

				r.keyPress(KeyEvent.VK_ENTER);

				r.keyRelease(KeyEvent.VK_ENTER);

				r.keyPress(KeyEvent.VK_CONTROL);
				r.keyPress(KeyEvent.VK_V);
				r.keyRelease(KeyEvent.VK_V);
				r.keyRelease(KeyEvent.VK_CONTROL);

				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);

			} catch (AWTException e) {
				return "Failed::" + e;

			}
		} catch (Exception e) {
			Log.error(" Not able to fileUploadinIE --- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Successfully  fileUploadinIE";

	}
	/**
	 * @param driver
	 * File download from Auto It
	 */
	public String filedownloadAUTOIT(WebDriver driver, String locatorType, String object) {
		try {
			Log.info("filedownloadAUTOIT ... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			WebElement filedownloadAUTOIT = driver.findElement(locator);
			// Runtime.getRuntime().exec(model.getData());
			Runtime.getRuntime().exec("");
		} catch (IOException e) {
			Log.error(" Not able to filedownloadAUTOIT --- " + e.getMessage());
			e.printStackTrace();
			return "Failed::" + e;
		}
		return "Pass :: Successfully  filedownloadAUTOIT";
	}
	/**
	 * @param driver
	 * SSL errors that appear on IE browser can be resolved
	 */
	public String certificateErrorsIE(WebDriver driver) {

		try {
			Log.info("certificateErrorsIE ... ");
			driver.navigate().to("javascript:document.getElementById('overridelink').click()");
		} catch (Exception e) {
			Log.error(" Not able to certificateErrorsIE --- " + e.getMessage());
			e.printStackTrace();
			return "Failed::" + e;
		}
		return "Pass :: Successfully  SSL errors that appear on IE browser can be resolved";

	}
	
	public String WriteWebTableXL(WebDriver driver, String locatorType, String object) {
		try {
			MethodWebTableWriteXL(driver, Constants.Path_TestData, Constants.Sheet_TestData, locatorType, object);
		} catch (Exception e) {
			Log.error("Value Not Found in table--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Table values written into Excel successfully..";

	}
	public String MethodWebTableWriteXL(WebDriver driver, String path,String sheet,String locatorType, String object)
			throws FileNotFoundException {
		try {

			Log.info("Getting Values in Table  ... " + object);
			By locator;
			locator = TestMethods.locatorValue(locatorType, object);
			WebElement mytable = driver.findElement(locator);
			FileInputStream fis = new FileInputStream(path);
			

			XSSFWorkbook wkb = new XSSFWorkbook(fis);
			XSSFSheet sheet1 = wkb.getSheet(sheet);

			// WebElement mytable =
			// driver.findElement(By.xpath(".//*[@id='mc_mainWrapper']/section/div/div[2]/aside/div[3]/div[2]/div[1]/table"));

			List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
			int rows_count = rows_table.size();
			System.out.println("Number of Rows " + rows_count);

			for (int row = 0; row < rows_count; row++) {

				XSSFRow excelRow = sheet1.createRow(row);
				if (row == 0) {
					List<WebElement> head_row = rows_table.get(row).findElements(By.tagName("th"));
					int Head_count = head_row.size();
					System.out.println("Number of Header cells In Row 0 are " + Head_count);

					for (int i = 0; i < Head_count; i++) {
						XSSFCell excelCell = excelRow.createCell(i);
						excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);
						String celtext = head_row.get(i).getText();
						excelCell.setCellValue(celtext);
						System.out.println("Header in valuein column number " + i + " Is " + celtext);
					}

				} else {
					List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
					int columns_count = Columns_row.size();
					System.out.println("Number of cells In Row " + row + " are " + columns_count);

					for (int column = 0; column < columns_count; column++) {
						XSSFCell excelCell = excelRow.createCell(column);
						excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);
						String celtext = Columns_row.get(column).getText();
						excelCell.setCellValue(celtext);
						System.out.println(
								"Cell Value Of row number " + row + " and column number " + column + " Is " + celtext);
					}

				}
				System.out.println("--------------------------------------------------");
			}
			try {
				FileOutputStream fos = new FileOutputStream(path);
				fos.flush();
				wkb.write(fos);
				fos.close();

				System.out.println("Excel written successfully..");

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			Log.error("Value Not Found--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Table values written into Excel successfully..";

	}
	public String WebTableColumnWriteIntoXL(WebDriver driver, String locatorType, String object) {
		try {
			MethodWebTableColumnWriteXL(driver, Constants.Path_TestData, Constants.Sheet_TestData, locatorType, object);
		} catch (Exception e) {
			Log.error("Column object Not Found in table--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Table values written into Excel successfully..";

	}

	public String MethodWebTableColumnWriteXL(WebDriver driver, String path, String sheet, String locatorType, String object)
			throws FileNotFoundException {
		try {

			Log.info("Getting Values in Table  ... " + object);
			By locator;
			locator = locatorValue(locatorType, object);
			FileInputStream fis = new FileInputStream(path);

			XSSFWorkbook wkb = new XSSFWorkbook(fis);
			XSSFSheet sheet1 = wkb.getSheet(sheet);
			List<WebElement> rows_table = driver.findElements(locator);
			int rows_count = rows_table.size();
			System.out.println("Number of Rows " + rows_count);

			for (int row = 0; row < rows_count; row++) {

				XSSFRow excelRow = sheet1.createRow(row);
				if (row == 0) {
					String head_row = rows_table.get(row).getText();
					// int Head_count = head_row.size();
					System.out.println("Number of Header cells In Row 0 are " + head_row);

					for (int i = 0; i < rows_count; i++) {
						XSSFCell excelCell = excelRow.createCell(i);
						excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);
						String celtext = rows_table.get(i).getText();
						excelCell.setCellValue(celtext);
						System.out.println("Column value in Row number " + i + " Is " + celtext);
					}

				}
			}
			try {
				FileOutputStream fos = new FileOutputStream(path);
				fos.flush();
				wkb.write(fos);
				fos.close();

				System.out.println("Excel written successfully..");
				System.out.println("--------------------------------------------------");

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			Log.error("Value Not Found--- " + e.getMessage());
			return "Failed::" + e;
		}
		return "Pass :: Table values written into Excel successfully..";

	}
	
	

	public static By locatorValue(String locatorType, String object) {
		By by;
		switch (locatorType) {
		case "id":
			by = By.id(object);
			break;
		case "name":
			by = By.name(object);
			break;
		case "xpath":
			by = By.xpath(object);
			break;
		case "css":
			by = By.cssSelector(object);
			break;
		case "linkText":
			by = By.linkText(object);
			break;
		case "partialLinkText":
			by = By.partialLinkText(object);
			break;
		case "className":
			by = By.className(object);
			break;
		case "tagName":
			by = By.tagName(object);
			break;
		default:
			by = null;
			break;
		}
		return by;
	}

}
