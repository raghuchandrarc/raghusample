package com.actions;

import org.openqa.selenium.WebDriver;

public class KeywordExecutor {

	TestMethods tests = new TestMethods(); // Creating object of a TestMethod
											// class
	/**
	 * This method will execute the test methods according to the keyword
	 * provided in excel sheet
	 * 
	 * @param driver
	 * @param TestCaseId
	 * @param TestCaseName
	 * @param keywordData
	 * @param locatorType
	 * @param object
	 * @param inputData
	 */
	String stepExecutionResult;

	public String execute(WebDriver driver, String TestCaseId, String TestCaseName, String keywordData,
			String locatorType, String object, String inputData) throws Exception {
		switch (keywordData) {
		case "OpenApplication":
			stepExecutionResult = tests.openUrl(driver, inputData);
			break;
		case "EnterText":
			stepExecutionResult = tests.enterText(driver, locatorType, object, inputData);
			break;
		case "Click":
			stepExecutionResult = tests.click(driver, locatorType, object);
			break;
		case "getText":
			stepExecutionResult = tests.getText(driver, locatorType, object);
			break;
		case "VerifyText":
			stepExecutionResult = tests.verifyText(driver, locatorType, object, inputData);
			break;
		case "waitFor":
			stepExecutionResult = tests.waitFor(driver, object, inputData);
			break;
		case "Clear":
			stepExecutionResult = tests.Clear(driver, locatorType, object);
			break;
		case "Select":
			stepExecutionResult = tests.Select(driver, locatorType, object, inputData);
			break;
		case "closeBrowser":
			stepExecutionResult = tests.closeBrowser(driver, locatorType);
			break;
		case "tableValueVerify":
			stepExecutionResult = tests.tableValueVerify(driver, locatorType, object, inputData);
			break;
		case "waitNclick":
			stepExecutionResult = tests.waitNclick(driver, locatorType, object);
			break;
		case "clickNSelect":
			stepExecutionResult = tests.clickNSelect(driver, locatorType, object);
			break;
		case "enterNSelect":
			stepExecutionResult = tests.enterTextSelect(driver, locatorType, object, inputData);
			break;
		case "dropDownByMouseHover":
			stepExecutionResult = tests.dropDownByMouseHover(driver, locatorType, object, inputData);
			break;
		case "singleMouseHover":
			stepExecutionResult = tests.singleMouseHover(driver, locatorType, object);
			break;
		case "waitForElement":
			stepExecutionResult = tests.waitForElement(driver, locatorType, object);
			break;
		case "WebTableFullWriteXL":
			stepExecutionResult = tests.WriteWebTableXL(driver, locatorType, object);
			break;
		case "WebTableColumnWriteIntoXL":
			stepExecutionResult = tests.WebTableColumnWriteIntoXL(driver, locatorType, object);
			break;
		case "tableValueClick":
			stepExecutionResult = tests.tableValueClick(driver, locatorType, object, inputData);
			break;
		case "scrollElementIntoView":
			stepExecutionResult = tests.scrollElementIntoView(driver, locatorType, object);
			break;
		case "VerifyLinks":
			stepExecutionResult = tests.VerifyLinks(driver, locatorType, object, inputData);
			break;

		default:
			System.out.println("Invalid Keyword");
			stepExecutionResult = "Invalid Keyword";
			break;
		}
		return stepExecutionResult;

	}
}
